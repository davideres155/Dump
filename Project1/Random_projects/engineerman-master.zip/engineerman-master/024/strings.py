# single line
text = "hello"

# multi line
multi_line = """line1""" \
	"""line2""" \
	"""line3"""

# substrings
name = 'engineer man'
first_name = name[0:8]

# integer
num1 = 6

# float
dec1 = 5.4

# conversion to string
to_string = str(num1)

# conversion to integer/float
num_string = '5'
to_int = int(num_string)
to_float = float(num_string)
