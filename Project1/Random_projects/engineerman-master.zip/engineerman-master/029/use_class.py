# inclusion
from person import Person

p = Person('Brian', 37)
p.say_name()
p.say_age()
p.have_birthday()
p.say_age()
p.have_birthday()
p.say_age()
p.have_birthday()
p.say_age()
p.have_birthday()
p.say_age()
