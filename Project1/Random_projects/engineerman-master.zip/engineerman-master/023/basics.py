# indentation
if True:
		print 'hello'
		print 'asd'

# commenting
# single-line comment

"""
line 1
line 2
line 3
"""

# variables
name = 'engineer man'

# multi-line
num1 = 5; num2 = 8

# continuance
long_name = \
	"something" + \
	"something else"

# printing
print 'hello world',
